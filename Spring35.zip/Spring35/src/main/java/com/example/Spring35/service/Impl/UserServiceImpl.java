package com.example.Spring35.service.Impl;

import com.example.Spring35.dto.UserDto;
import com.example.Spring35.entity.Role;
import com.example.Spring35.entity.User;
import com.example.Spring35.repository.RoleRepository;
import com.example.Spring35.repository.UserRepository;
import com.example.Spring35.service.UserService;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {

    public UserRepository userRepository;
    public RoleRepository roleRepository;
    public ModelMapper modelMapper;
    public PasswordEncoder passwordEncoder;

    @Override
    public UserDto saveUserDetails(UserDto userDto) {
        User saveUser = convertToEntity(userDto);
        Role role = roleRepository.findByName("ROLE_ADMIN");
        if (role == null) {
            role = checkRoleExist();
        }
        saveUser.setRoles(Arrays.asList(role));
        saveUser.setName(userDto.getFirstName() + " " + userDto.getLastName());
        saveUser.setPassword(passwordEncoder.encode(userDto.getPassword()));
        return convertToDto(userRepository.save(saveUser));
    }

    private Role checkRoleExist() {

        Role role = new Role();
        role.setName("ROLE_ADMIN");
        return roleRepository.save(role);
    }


    @Override
    public UserDto findUserByEmail(String email) {
        User user = userRepository.findByEmail(email);
        if (user == null) {
            return new UserDto();
        }
        return convertToDto(user);
    }

    @Override
    public List<UserDto> findAllUsers() {

        return userRepository.findAll()
                .stream()
                .map(user -> {
                    UserDto userDto = convertToDto(user);
                    return userDto;
                }).toList();

    }


    public User convertToEntity(UserDto userDto) {
        return modelMapper.map(userDto, User.class);
    }

    public UserDto convertToDto(User user) {
        return modelMapper.map(user, UserDto.class);
    }


}
