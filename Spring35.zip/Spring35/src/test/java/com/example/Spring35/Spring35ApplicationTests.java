package com.example.Spring35;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring35ApplicationTests {

	@Test
	void contextLoads() {
	}

}
